﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataFirst.Models;
namespace DataFirst.Controllers
{
    public class UserController : Controller
    {
        //
        // GET: /User/
        Database1Entities db = new Database1Entities();
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(Registration r)
        {
            db.Registrations.Add(r);
            db.SaveChanges();
            ViewBag.data = "Registration Successfully";
            return View();
        }

        public ActionResult UserLogin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult UserLogin(Registration r)
        {
            var s = (from c in db.Registrations where c.userid == r.userid && c.password == r.password select c).FirstOrDefault();
            if (s != null)
            {
                TempData["uid"] = r.userid;
                TempData.Keep();
                return RedirectToAction("Index", "UserDash");
            }
            ViewBag.data = "Invalid UserId and Password";
            return View();
        }

       
    }
}
