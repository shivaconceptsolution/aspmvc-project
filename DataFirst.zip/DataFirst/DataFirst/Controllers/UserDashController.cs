﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataFirst.Models;
namespace DataFirst.Controllers
{
    public class UserDashController : Controller
    {
        //
        // GET: /UserDash/
        Database1Entities db = new Database1Entities();
        public ActionResult Index()
        {
            TempData.Keep();
            string uid = TempData["uid"].ToString();
            var s = (from c in db.Registrations where c.userid == uid select c).FirstOrDefault();
            ViewBag.data = "Username is " + s.userid + " Password is " + s.password + "Emailid is " + s.email + "Mobile no is " + s.mobileno;


            return View();
        }
        public ActionResult Logout()
        {
            TempData.Remove("uid");
            return RedirectToAction("Index", "User");
        }
    }
}
